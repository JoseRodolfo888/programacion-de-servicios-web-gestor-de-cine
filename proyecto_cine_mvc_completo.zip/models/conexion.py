import mysql.connector

class Conexion:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="123456",
            database="cine"
        )
        self.cursor = self.conn.cursor(dictionary=True)
