from tkinter import messagebox
from models.usuario_model import UsuarioModel

class UsuarioController:
    def __init__(self, root):
        self.model = UsuarioModel()
        self.root = root

    def validar_login(self, correo, password):
        usuario = self.model.login(correo, password)
        if usuario:
            messagebox.showinfo("Bienvenido", f"Hola {usuario['nombre']} ({usuario['rol']})")
        else:
            messagebox.showerror("Error", "Credenciales inválidas")
