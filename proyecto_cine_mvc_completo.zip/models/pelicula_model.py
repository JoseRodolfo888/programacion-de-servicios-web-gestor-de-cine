from .conexion import Conexion
import mysql.connector

class PeliculaModel(Conexion):
    def obtener_todas(self):
        self.cursor.execute("SELECT * FROM peliculas ORDER BY titulo")
        return self.cursor.fetchall()

    def agregar(self, titulo, director, duracion, clasificacion, genero):
        query = "INSERT INTO peliculas (titulo, director, duracion, clasificacion, genero) VALUES (%s,%s,%s,%s,%s)"
        self.cursor.execute(query, (titulo, director, duracion, clasificacion, genero))
        self.conn.commit()

    def actualizar(self, id_pelicula, titulo, director, duracion, clasificacion, genero):
        query = "UPDATE peliculas SET titulo=%s, director=%s, duracion=%s, clasificacion=%s, genero=%s WHERE id_pelicula=%s"
        self.cursor.execute(query, (titulo, director, duracion, clasificacion, genero, id_pelicula))
        self.conn.commit()

    def eliminar(self, id_pelicula):
        try:
            self.cursor.execute("DELETE FROM funciones WHERE id_pelicula = %s", (id_pelicula,))
            self.cursor.execute("DELETE FROM peliculas WHERE id_pelicula = %s", (id_pelicula,))
            self.conn.commit()
        except mysql.connector.Error as err:
            self.conn.rollback()
            raise err

    def buscar(self, termino):
        query = "SELECT * FROM peliculas WHERE titulo LIKE %s OR genero LIKE %s ORDER BY titulo"
        self.cursor.execute(query, (f"%{termino}%", f"%{termino}%"))
        return self.cursor.fetchall()
