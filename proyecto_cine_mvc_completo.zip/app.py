import tkinter as tk
from controllers.usuario_controller import UsuarioController
from views.login_view import LoginView

if __name__ == "__main__":
    root = tk.Tk()
    root.title("CineMagic Premium")
    controller = UsuarioController(root)
    LoginView(root, controller)
    root.mainloop()
