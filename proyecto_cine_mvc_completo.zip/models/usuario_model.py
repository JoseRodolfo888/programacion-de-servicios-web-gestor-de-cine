from .conexion import Conexion

class UsuarioModel(Conexion):
    def login(self, correo, contraseña):
        query = """
        SELECT u.*, r.nombre as rol
        FROM usuarios u
        JOIN roles r ON u.id_rol = r.id_rol
        WHERE u.correo = %s AND u.contraseña = %s
        """
        self.cursor.execute(query, (correo, contraseña))
        return self.cursor.fetchone()
    
    def registrar(self, nombre, edad, correo, contraseña):
        query = "INSERT INTO usuarios (nombre, edad, correo, contraseña, id_rol) VALUES (%s,%s,%s,%s,2)"
        self.cursor.execute(query, (nombre, edad, correo, contraseña))
        self.conn.commit()
