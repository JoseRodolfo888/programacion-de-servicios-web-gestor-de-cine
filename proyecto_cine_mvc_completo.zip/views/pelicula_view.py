import tkinter as tk
from tkinter import ttk, messagebox

class PeliculaView:
    def __init__(self, root, controller):
        self.root = root
        self.controller = controller
        self.frame = ttk.Frame(root)
        self.frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(self.frame, text="Gestión de Películas", font=("Arial", 14, "bold")).pack(pady=10)

        # Botones
        button_frame = ttk.Frame(self.frame)
        button_frame.pack(pady=10)

        ttk.Button(button_frame, text="Ver todas", command=self.controller.mostrar_todas).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Agregar", command=self.agregar).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="Buscar", command=self.buscar).grid(row=0, column=2, padx=5)

        # Área de resultados
        self.result_frame = ttk.Frame(self.frame)
        self.result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def limpiar_resultados(self):
        for widget in self.result_frame.winfo_children():
            widget.destroy()

    def mostrar_peliculas(self, peliculas):
        self.limpiar_resultados()
        if not peliculas:
            ttk.Label(self.result_frame, text="No hay resultados.").pack()
            return

        tree = ttk.Treeview(self.result_frame, columns=("ID", "Título", "Director", "Duración", "Clasificación", "Género"), show="headings")
        for col in ("ID", "Título", "Director", "Duración", "Clasificación", "Género"):
            tree.heading(col, text=col)
        tree.pack(fill=tk.BOTH, expand=True)

        for p in peliculas:
            tree.insert("", "end", values=(p['id_pelicula'], p['titulo'], p['director'], p['duracion'], p['clasificacion'], p['genero']))

    def agregar(self):
        win = tk.Toplevel(self.root)
        win.title("Agregar Película")
        fields = ["Título", "Director", "Duración", "Clasificación", "Género"]
        entries = {}
        for f in fields:
            ttk.Label(win, text=f).pack()
            e = ttk.Entry(win)
            e.pack()
            entries[f] = e
        ttk.Button(win, text="Guardar", command=lambda: self.controller.agregar(entries, win)).pack(pady=10)

    def buscar(self):
        win = tk.Toplevel(self.root)
        win.title("Buscar Película")
        ttk.Label(win, text="Término de búsqueda:").pack()
        entry = ttk.Entry(win)
        entry.pack()
        ttk.Button(win, text="Buscar", command=lambda: self.controller.buscar(entry.get(), win)).pack(pady=10)
