from tkinter import messagebox
from models.pelicula_model import PeliculaModel

class PeliculaController:
    def __init__(self, root, view_class):
        self.model = PeliculaModel()
        self.root = root
        self.view = view_class(root, self)

    def mostrar_todas(self):
        peliculas = self.model.obtener_todas()
        self.view.mostrar_peliculas(peliculas)

    def agregar(self, entries, win):
        try:
            titulo = entries['Título'].get()
            director = entries['Director'].get()
            duracion = int(entries['Duración'].get())
            clasificacion = entries['Clasificación'].get()
            genero = entries['Género'].get()
            self.model.agregar(titulo, director, duracion, clasificacion, genero)
            messagebox.showinfo("Éxito", "Película agregada")
            win.destroy()
            self.mostrar_todas()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo agregar: {e}")

    def buscar(self, termino, win):
        peliculas = self.model.buscar(termino)
        self.view.mostrar_peliculas(peliculas)
        win.destroy()
