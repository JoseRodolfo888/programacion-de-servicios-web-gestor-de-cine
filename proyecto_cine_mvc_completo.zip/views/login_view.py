import tkinter as tk
from tkinter import ttk

class LoginView:
    def __init__(self, root, controller):
        self.root = root
        self.controller = controller
        self.frame = ttk.Frame(root)
        self.frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(self.frame, text="Correo:").pack()
        self.correo_entry = ttk.Entry(self.frame)
        self.correo_entry.pack()

        ttk.Label(self.frame, text="Contraseña:").pack()
        self.pass_entry = ttk.Entry(self.frame, show="*")
        self.pass_entry.pack()

        ttk.Button(self.frame, text="Iniciar sesión", command=self.login).pack()

    def login(self):
        correo = self.correo_entry.get()
        password = self.pass_entry.get()
        self.controller.validar_login(correo, password)
